package com.springboot.myfirstwebapp.login;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
// Keep the data in session storage
@SessionAttributes("name")
public class LoginController {
	
	private AuthenticationService authenticationService;
	//	Auto wiring using Constructor to connect olther method in this class
	public LoginController(AuthenticationService authenticationService) {
		super();
		this.authenticationService = authenticationService;
	}
	
//	Handelling GET, POST
//	Use this method for only GET
	@RequestMapping(value="/login", method = RequestMethod.GET)
	public String gotoLoginPage() {
		return "login";
	}
	

	//	When clicking on submit it will do POST request and go to welcome.jsp
//	Capturing form input value using @RequestParam
	@RequestMapping(value="/login", method = RequestMethod.POST)
	public String gotoWelcomePage(@RequestParam String name, @RequestParam String password, ModelMap model) {
		if(authenticationService.authentication(name, password)) {
			model.put("name", name);
//			model.put("password", password);
			return "welcome";
		}
		model.put("errorMessage", "Invalid Credentials");
			return "login";
	}
}
