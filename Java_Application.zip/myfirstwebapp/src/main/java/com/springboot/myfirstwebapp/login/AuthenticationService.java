package com.springboot.myfirstwebapp.login;

import org.springframework.stereotype.Service;

@Service
public class AuthenticationService {
	public boolean authentication(String username, String password) {
		boolean isValidUserName = username.equalsIgnoreCase("deep@gmail.com");
		boolean isValidPassword = password.equalsIgnoreCase("Dummy");
		return isValidUserName && isValidPassword;
	}
}
