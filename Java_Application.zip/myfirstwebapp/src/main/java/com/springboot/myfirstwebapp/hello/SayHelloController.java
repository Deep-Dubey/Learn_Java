package com.springboot.myfirstwebapp.hello;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class SayHelloController {
	
	@RequestMapping("/say-hello")
	@ResponseBody
	public String sayHello() {
		return "Hello! What are you learning today?";
	}
	
//	This is the bad practice to create html page
	@RequestMapping("/say-hello-html")
	@ResponseBody
	public String sayHelloHtml() {
		StringBuffer sb = new StringBuffer();
		sb.append("<html>");
		sb.append("<head>");
		sb.append("<title>My first web app</title>");
		sb.append("</head>");
		sb.append("<body>");
		sb.append("<h1>My name is deep dubey</h1>");
		sb.append("</body>");
		sb.append("</html>");
		return sb.toString();
	}
	
//	Creating views using JSP
//	We can create as many JSP file we need
//	src/main/resource/META-INF/resource/WEB-INF/jsp/sayHello.jsp
//	src/main/resource/META-INF/resource/WEB-INF/jsp/welcome.jsp
//	src/main/resource/META-INF/resource/WEB-INF/jsp/login.jsp
//	src/main/resource/META-INF/resource/WEB-INF/jsp/todos.jsp
//	If there will be a @responceBody then it will not go to JSP
//	In return statement we have to provide the jsp file name
	
	@RequestMapping("say-hello-jsp")
	public String sayHelloJsp() {
		return "sayHello";
	}
}
